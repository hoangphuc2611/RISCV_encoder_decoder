This is a modified RISCV translator.
Assuming you already have NodeJS, the translating process is simple.
You only need to run this command.

node new.js source dest

source: This is the source file of your program, can be in assembly, hex, or binary.
dest: This is the output file of your in assembly.
